function t796_init(recid){var el=$("#rec"+recid);var shapeEl=el.find(".t796__shape-border");var recs=el.find(".t796").attr("data-shape-rec-ids");if(typeof recs!="undefined"){recs=recs.split(",");recs.forEach(function(rec_id,i,arr){var curRec=$("#rec"+rec_id);var curShapeEl=shapeEl.clone();t796_setColor(el,curShapeEl);t796_addDivider(curRec,curShapeEl)})}else{if(shapeEl.hasClass('t796__shape-border_top')||shapeEl.hasClass('t796__shape-border_top-flip')){var curRec=el.next(".r");if(curRec.attr("data-record-type")=="215"||curRec.attr("data-record-type")=="706"){curRec=curRec.next(".r")}}
if(shapeEl.hasClass('t796__shape-border_bottom')||shapeEl.hasClass('t796__shape-border_bottom-flip')){var curRec=el.prev(".r");if(curRec.attr("data-record-type")=="215"||curRec.attr("data-record-type")=="706"){curRec=curRec.prev(".r")}}
if(curRec.length!=0){var curShapeEl=shapeEl.clone();t796_setColor(el,curShapeEl);t796_addDivider(curRec,curShapeEl)}}}
function t796_addDivider(curRec,curShapeEl){curRec.attr("data-animationappear","off").removeClass('r_hidden');var coverWrapper=curRec.find(".t-cover");var zeroWrapper=curRec.find(".t396");if(coverWrapper.length>0||zeroWrapper.length>0){if(coverWrapper.length>0){coverWrapper.find(".t-cover__filter").after(curShapeEl)}
if(zeroWrapper.length>0){zeroWrapper.after(curShapeEl);curRec.css("position","relative")}
curShapeEl.css("display","block")}else{var wrapper=curRec;var curRecType=curRec.attr("data-record-type");if(wrapper.length==0){return!0}
wrapper.append(curShapeEl);wrapper.css("position","relative");if(curRecType!="554"&&curRecType!="125"){wrapper.children("div").first().css({"position":"relative","z-index":"1"}).addClass("t796_cont-near-shape-divider")}
if(curRecType=="734"||curRecType=="675"||curRecType=="279"||curRecType=="694"){curShapeEl.css("z-index","1")}
curShapeEl.css("display","block")}}
function t796_setColor(el,curShapeEl){if(typeof curShapeEl.attr("data-fill-color")!="undefined"){return}
if(curShapeEl.hasClass("t796__shape-border_bottom")||curShapeEl.hasClass("t796__shape-border_bottom-flip")){var nearestBlock=el.next(".r")}else{var nearestBlock=el.prev(".r")}
if(nearestBlock.length==0){return}
var fillColor=nearestBlock.attr("data-bg-color");if(typeof fillColor=="undefined"){return}
curShapeEl.find(".t796__svg").css("fill",fillColor)}